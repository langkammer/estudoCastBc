import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { finalize } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public nome:string = "a";
  public telefone:string = "a";
  public lista :any= [];

  constructor(private http: HttpClient) {
    this.listar();
  }





  public listar(){
   return this.http.get("http://localhost:9000/clientes").subscribe(
      data => this.lista = data,
      error => console.log(error)
    );
  }
}
